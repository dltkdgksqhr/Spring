package com.ezfarm.fes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FesApplicationTests {

	@Test
	void contextLoads() {
	}

}
