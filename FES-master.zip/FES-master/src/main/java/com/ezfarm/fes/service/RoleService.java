package com.ezfarm.fes.service;

import java.util.List;

import com.ezfarm.fes.vo.RoleVo;

public interface RoleService {

	public List<RoleVo> selectRoles();

}
