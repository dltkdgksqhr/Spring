package com.ezfarm.fes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FesApplication {

	public static void main(String[] args) {
		SpringApplication.run(FesApplication.class, args);
	}

}
