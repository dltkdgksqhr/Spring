package com.ezfarm.fes.vo;

import lombok.Data;

@Data
public class RoleVo {
	
	Long roleSeq;
	String roleName;
	String roleCode;

}
